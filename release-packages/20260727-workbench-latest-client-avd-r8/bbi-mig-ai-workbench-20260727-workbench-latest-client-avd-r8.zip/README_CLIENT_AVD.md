# Workbench Latest Client AVD r8

This is a source-only delta overlay for:

`20260724-warehouse-cost-rollover-client-avd-r7`

It contains the prepared-workspace context, assistant streaming/orchestration,
target-column FIR intelligence, durable FIR jobs, auto-mapping agent updates,
deployment propagation, and related tests completed after r7.

## Apply

1. Back up the client AVD checkout.
2. Extract the ZIP into the repository root and allow matching files to be
   overwritten.
3. Merge the settings in `CLIENT_ENV_DELTA.md` into the existing
   `infra/snowflake/env/client.env`; the real client environment file is not
   included.
4. Run `scripts/bootstrap_sttm_metadata_infra.ps1` to apply the new metadata,
   FIR tables, procedures, and agent specifications.
5. Deploy with `scripts/deploy_spcs_client_snow_safe.ps1`.

The package intentionally excludes Docker files, actual environment files,
build output, virtual environments, client data, and EverNest reference files.

## Verification represented by this package

- Frontend TypeScript check passed.
- Focused backend suite passed: 44 tests.
- Agent specification manifest verification passed, including
  `AGT_SOURCE_MAPPING` and `AGT_TRANSFORMATION_RULE`.
- SPCS shell deployment script syntax passed.
- Required V2 settings are propagated to both web and auto-map service specs.

